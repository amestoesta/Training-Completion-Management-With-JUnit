package com.example.demo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

import org.springframework.dao.EmptyResultDataAccessException;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;

import com.example.demo.trainee.model.Trainee;
import com.example.demo.trainee.repository.TraineeRepository;
import com.example.demo.trainee.service.TraineeService;
import com.example.demo.training.model.Training;
import com.example.demo.training.repository.TrainingRepository;

@RunWith(MockitoJUnitRunner.class)
public class TraineeServiceTest {
	
	@Mock
	private TraineeRepository traineeRepository;

	@Mock
	private TrainingRepository trainingRepository;

	@InjectMocks
	private TraineeService traineeService;

	@BeforeEach
	void setup() {
		MockitoAnnotations.openMocks(this);
	}

	@Test
	void should_save_one_trainee() {
		Trainee trainee = new Trainee();
		Mockito.when(traineeRepository.save(trainee)).thenReturn(trainee);

		Assertions.assertDoesNotThrow(() -> traineeService.saveTrainee(trainee));

		Mockito.verify(traineeRepository, Mockito.times(1)).save(trainee);
	}

	@Test
	void should_not_save_trainee() {
		Trainee trainee = new Trainee();
		Mockito.when(traineeRepository.save(trainee)).thenReturn(null);

		 Assertions.assertThrows(Exception.class, () -> traineeService.saveTrainee(trainee));

		Mockito.verify(traineeRepository, Mockito.times(1)).save(trainee);
	}
	
	@Test
	void should_find_trainee_details_with_id_not_null() {
		Long traineeId = 21111L;
		List<Trainee> expectedTrainees = new ArrayList<>();
		Trainee trainee = new Trainee();
		expectedTrainees.add(trainee);

		Mockito.when(traineeRepository.findAllByTraineeId(traineeId)).thenReturn(expectedTrainees);

		List<Trainee> actualTrainees = traineeService.getTraineeDetails(traineeId);

		Assertions.assertEquals(expectedTrainees, actualTrainees);

		Mockito.verify(traineeRepository, Mockito.times(1)).findAllByTraineeId(traineeId);
		Mockito.verify(traineeRepository, Mockito.never()).findAll();
	}

	@Test
	void should_find_trainee_details_with_id_null() {
		List<Trainee> expectedTrainees = new ArrayList<>();
		Trainee trainee = new Trainee();
		expectedTrainees.add(trainee);

		Mockito.when(traineeRepository.findAll()).thenReturn(expectedTrainees);

		List<Trainee> actualTrainees = traineeService.getTraineeDetails(null);

		Assertions.assertEquals(expectedTrainees, actualTrainees);

		Mockito.verify(traineeRepository, Mockito.times(1)).findAll();
		Mockito.verify(traineeRepository, Mockito.never()).findAllByTraineeId(Mockito.anyLong());
	}

	@Test
	void should_delete_one_trainee() {
		Long traineeId = 1L;

		// Mock the behavior of deleteById() to throw an exception when the trainee doesn't exist
	    Mockito.doThrow(EmptyResultDataAccessException.class).when(traineeRepository).deleteById(traineeId);

	    // Assert that the exception is thrown when deleting the trainee
	    Assertions.assertThrows(EmptyResultDataAccessException.class, () -> {
	        traineeService.deleteTrainee(traineeId);
	    });

	    // Verify that deleteById() was called exactly once with the traineeId
	    Mockito.verify(traineeRepository, Mockito.times(1)).deleteById(traineeId);
	}
	
	@Test
	void should_assign_training_to_trainee() {
		Long traineeId = 1L;
		Long trainingId = 1L;
		Set<Training> trainingSet = new HashSet<>();
		Trainee trainee = new Trainee();
		Training training = new Training();
		trainingSet.add(training);

		Mockito.when(traineeRepository.findById(traineeId)).thenReturn(Optional.of(trainee));
		Mockito.when(trainingRepository.findById(trainingId)).thenReturn(Optional.of(training));
		Mockito.when(traineeRepository.save(trainee)).thenReturn(trainee);

		Trainee result = traineeService.assignTrainingToTrainee(traineeId, trainingId);

		Assertions.assertEquals(trainee, result);
		Assertions.assertEquals(trainingSet, trainee.getAssignedTrainings());

		Mockito.verify(traineeRepository, Mockito.times(1)).findById(traineeId);
		Mockito.verify(trainingRepository, Mockito.times(1)).findById(trainingId);
		Mockito.verify(traineeRepository, Mockito.times(1)).save(trainee);
	}

	@Test
	void should_not_assign_training_to_trainee() {
	    Long traineeId = 52L;
	    Long trainingId = 1L;
	    Set<Training> trainingSet = new HashSet<>();
	    Trainee trainee = new Trainee();
	    Training training = new Training();
	    trainingSet.add(training);

	    Mockito.when(traineeRepository.findById(traineeId)).thenReturn(Optional.empty());
	    Mockito.when(trainingRepository.findById(trainingId)).thenReturn(Optional.of(training));

	    Trainee result = traineeService.assignTrainingToTrainee(traineeId, trainingId);

	    Assertions.assertNull(result);
	    Assertions.assertNotEquals(trainingSet, trainee.getAssignedTrainings());

	    Mockito.verify(traineeRepository, Mockito.times(1)).findById(traineeId);
	    Mockito.verify(trainingRepository, Mockito.times(1)).findById(trainingId);
	    Mockito.verify(traineeRepository, Mockito.never()).save(trainee);
	}

	
	@Test
	void should_update_one_trainee_field() {
		Long traineeId = 1L;
		Map<String, Object> fields = new HashMap<>();
		fields.put("position", "Frontend Developer");

		Trainee trainee = new Trainee();
		Optional<Trainee> traineeOptional = Optional.of(trainee);

		Mockito.when(traineeRepository.findById(traineeId)).thenReturn(traineeOptional);
		Mockito.when(traineeRepository.save(trainee)).thenReturn(trainee);

		Trainee result = traineeService.updateTraineeFields(traineeId, fields);

		Assertions.assertEquals(trainee, result);
		Assertions.assertEquals("Frontend Developer", trainee.getPosition());

		Mockito.verify(traineeRepository, Mockito.times(1)).findById(traineeId);
		Mockito.verify(traineeRepository, Mockito.times(1)).save(trainee);
	}
	
	@Test
	void should_not_update_trainee_field() {
	    Long traineeId = 1L;
	    Map<String, Object> fields = new HashMap<>();
	    fields.put("position", "Frontend Developer");

	    Trainee trainee = new Trainee();
	    Optional<Trainee> traineeOptional = Optional.of(trainee);

	    Mockito.when(traineeRepository.findById(traineeId)).thenReturn(traineeOptional);
	    Mockito.when(traineeRepository.save(trainee)).thenReturn(null); // Returning null to simulate not saving

	    Trainee result = traineeService.updateTraineeFields(traineeId, fields);

	    Assertions.assertNull(result); // Asserting that the result is null
	    Assertions.assertNotEquals("Frontend Developer", trainee.getPosition()); // Asserting that the position was not updated
	    Assertions.assertNull(trainee.getPosition()); // Asserting that the position field remains empty

	    Mockito.verify(traineeRepository, Mockito.times(1)).findById(traineeId);
	    Mockito.verify(traineeRepository, Mockito.times(1)).save(trainee);
	}


}