package com.example.demo;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.fail;

import java.time.Instant;
import java.time.LocalDate;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Set;

import org.junit.jupiter.api.Test;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.dao.EmptyResultDataAccessException;

import com.example.demo.trainee.model.Trainee;
import com.example.demo.trainee.repository.TraineeRepository;
import com.example.demo.trainee.service.TraineeService;
import com.example.demo.training.model.Training;
import com.example.demo.training.repository.TrainingRepository;

@SpringBootTest
class TrackingCompletionApplicationTests {

	@Autowired
	private TraineeRepository traineeRepository;

	@Autowired
	private TrainingRepository trainingRepository;

	@Autowired
	private TraineeService traineeService;

	// create trainee info
	@Test
	public void testCreateTrn() {
		try {
			Trainee trainee = new Trainee();
			trainee.setTraineeId(Instant.now().toEpochMilli());
			trainee.setName("Zaguirre Froilan");
			trainee.setPosition("Lead Developer");
			trainee.setStartDate(LocalDate.now());
			trainee.setEndDate(LocalDate.now().plusMonths(3));

			// validate the required fields
			if (trainee.getName() == null || trainee.getName().isEmpty()) {
				throw new IllegalArgumentException("Error: Activity name is required.");
			}
			if (trainee.getPosition() == null || trainee.getPosition().isEmpty()) {
				throw new IllegalArgumentException("Error: Position is required.");
			}
			if (trainee.getStartDate() == null) {
				throw new IllegalArgumentException("Error: Start date is required.");
			}
			if (trainee.getEndDate() == null) {
				throw new IllegalArgumentException("Error: End date is required.");
			}

			traineeRepository.save(trainee);
		
		} catch (IllegalArgumentException e) {
			fail("All fields are required: " + e.getMessage());
		} catch (Exception e) {
			fail("Exception thrown while creating trainee: " + e.getMessage());
		}

	}

	// read the all the trainee
	@Test
	public void testReadAll() {
		try {
			List<Trainee> trainees = traineeRepository.findAll();
			assertNotNull(trainees, "Trainee list should not be null");
			assertThat(trainees.size()).as("Expected trainee list size to be greater than 10").isGreaterThan(10);

		} catch (EmptyResultDataAccessException e) {
			fail("No trainings found in the database");
		} catch (IllegalArgumentException e) {
			fail("Invalid argument passed to findAll method");
		} catch (Exception e) {
			fail("Exception thrown while reading trainees: " + e.getMessage());
		}
	}

	private void assertNotNull(List<Trainee> trainees, String string) {
		// TODO Auto-generated method stub

	}

	// read trainee single field
	@Test
	public void testTraineeInfo() {
		Long traineeId = 752L;
		try {
			Trainee trainee = traineeRepository.findById(traineeId)
					.orElseThrow(() -> new NoSuchElementException("No trainee found with ID " + traineeId));
			assertThat(trainee.getPosition().equalsIgnoreCase("Full Stack Developer")).isTrue();

		} catch (IllegalArgumentException e) {
			fail(e.getMessage());
		} catch (Exception e) {
			fail("Exception thrown while reading trainee info: " + e.getMessage());
		}
	}

	// update existing trainee info
	@Test
	public void testInfoUpdate() {
		Long traineeId = 102L;
		try {
			Trainee trainee = traineeRepository.findById(traineeId)
					.orElseThrow(() -> new NoSuchElementException("No trainee found with ID " + traineeId));
			trainee.setName("Bonnel Dela Cruz");
			trainee.setPosition("Full Stack Developer");
			trainee.setStartDate(LocalDate.now().plusDays(5));
			trainee.setEndDate(LocalDate.now().plusMonths(3));

			// Validate the required fields
			if (trainee.getName() == null || trainee.getName().isEmpty()) {
				throw new IllegalArgumentException("Error: Activity name is required.");
			}
			if (trainee.getPosition() == null || trainee.getPosition().isEmpty()) {
				throw new IllegalArgumentException("Error: Position is required.");
			}
			if (trainee.getStartDate() == null) {
				throw new IllegalArgumentException("Error: Start date is required.");
			}
			if (trainee.getEndDate() == null) {
				throw new IllegalArgumentException("Error: End date is required.");
			}

			traineeRepository.save(trainee);

			Trainee updatedTrainee = traineeRepository.findById(traineeId)
					.orElseThrow(() -> new NoSuchElementException("No trainee found with ID " + traineeId));

			assertNotNull(updatedTrainee);

		} catch (IllegalArgumentException e) {
			fail("All fields are required: " + e.getMessage());
		} catch (Exception e) {
			fail("Exception thrown: " + e.getMessage());
		}
	}

	private void assertNotNull(Trainee updatedTrainee) {
		// TODO Auto-generated method stub
		
	}

	// delete trainee info
	@Test
	public void testTraineeDelete() {
		Long traineeId = 1302L;

		try {
			boolean existsBefore = traineeRepository.existsById(traineeId);
			if (!existsBefore) {
				throw new NoSuchElementException("No trainee found with ID " + traineeId);
			}
			traineeRepository.deleteById(traineeId);

			assertFalse(traineeRepository.existsById(traineeId));

		} catch (Exception e) {
			fail("Exception thrown: " + e.getMessage());
		}
	}

	@Test
	public void testAssignTrainingToTrainee() {
		try {
			// get an existing trainee and training from the repository
			Long traineeId = 602L;
			Long trainingId = 102L;
			Trainee trainee = traineeRepository.findById(traineeId)
					.orElseThrow(() -> new NoSuchElementException("No trainee found with ID " + traineeId));
			Training training = trainingRepository.findById(trainingId)
					.orElseThrow(() -> new NoSuchElementException("No training found with ID " + trainingId));

			// call the method to assign the training to the trainee
			Trainee assignedTrainee = traineeService.assignTrainingToTrainee(traineeId, trainingId);

			// check if the training was added to the trainee's assigned trainings
			Set<Training> assignedTrainings = assignedTrainee.getAssignedTrainings();
			assertThat(assignedTrainings.contains(training));

		} catch (NoSuchElementException e) {
			fail("No data found: " + e.getMessage());
		} catch (Exception e) {
			fail("Exception thrown: " + e.getMessage());
		}
	}

}
