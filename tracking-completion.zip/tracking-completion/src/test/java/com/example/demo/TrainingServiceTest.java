package com.example.demo;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;

import com.example.demo.training.model.Training;
import com.example.demo.training.repository.TrainingRepository;
import com.example.demo.training.service.TrainingService;

@RunWith(MockitoJUnitRunner.class)
public class TrainingServiceTest {

    @Mock
    private TrainingRepository trainingRepository;

    @InjectMocks
    private TrainingService trainingService;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);
    }
    
    @Test
	void should_save_one_training() {
    	 Training training = new Training();
		Mockito.when(trainingRepository.save(training)).thenReturn(training);

		Assertions.assertDoesNotThrow(() -> trainingService.saveTraining(training));

		Mockito.verify(trainingRepository, Mockito.times(1)).save(training);
	}
    
    @Test
    void should_not_save_training() {
        Training training = new Training();
        Mockito.when(trainingRepository.save(training)).thenReturn(null);

        Assertions.assertThrows(Exception.class, () -> trainingService.saveTraining(training));

        Mockito.verify(trainingRepository, Mockito.times(1)).save(training);
    }

    @Test
    public void should_find_trainingid_details_with_trainingid() {
        Long trainingId = 1L;
        List<Training> expectedTrainingList = new ArrayList<>();
        Mockito.when(trainingRepository.findAllByTrainingId(trainingId)).thenReturn(expectedTrainingList);

        List<Training> result = trainingService.getTrainingDetails(trainingId);

        Mockito.verify(trainingRepository, Mockito.times(1)).findAllByTrainingId(trainingId);
        Assertions.assertEquals(expectedTrainingList, result);
    }

    @Test
    public void should_find_trainingid_details_without_trainingid() {
        List<Training> expectedTrainingList = new ArrayList<>();
        Mockito.when(trainingRepository.findAll()).thenReturn(expectedTrainingList);

        List<Training> result = trainingService.getTrainingDetails(null);

        Mockito.verify(trainingRepository, Mockito.times(1)).findAll();
        Assertions.assertEquals(expectedTrainingList, result);
    }

    @Test
    public void should_delete_one_training() {
        Long trainingId = 1L;

        trainingService.deleteTraining(trainingId);

        Mockito.verify(trainingRepository, Mockito.times(1)).deleteById(trainingId);
    }

    @Test
    public void should_update_trainee_fields() throws NoSuchFieldException {
        Long trainingId = 1L;
        Training training = new Training();
        training.setTrainingId(trainingId);

        Map<String, Object> fields = new HashMap<>();
        fields.put("name", "Updated Training");

        Optional<Training> optionalTraining = Optional.of(training);
        Mockito.when(trainingRepository.findById(trainingId)).thenReturn(optionalTraining);

        Training updatedTraining = new Training();
        updatedTraining.setTrainingId(trainingId);
        updatedTraining.setActName("Updated Training");
        Mockito.when(trainingRepository.save(Mockito.any(Training.class))).thenReturn(updatedTraining);

        Training result = trainingService.updateTrainingFields(trainingId, fields);

        Mockito.verify(trainingRepository, Mockito.times(1)).findById(trainingId);
        Mockito.verify(trainingRepository, Mockito.times(1)).save(Mockito.any(Training.class));
        Assertions.assertEquals(updatedTraining, result);
    }

    @Test
    public void should_update_trainee_fields_with_invalid_trainingid() {
        Long trainingId = 1L;
        Map<String, Object> fields = new HashMap<>();
        fields.put("name", "Updated Training");
        fields.put("duration", 10);

        Mockito.when(trainingRepository.findById(trainingId)).thenReturn(Optional.empty());

        Training result = trainingService.updateTrainingFields(trainingId, fields);

        Mockito.verify(trainingRepository, Mockito.times(1)).findById(trainingId);
        Mockito.verify(trainingRepository, Mockito.times(0)).save(Mockito.any(Training.class));
        Assertions.assertNull(result);
    }
}
