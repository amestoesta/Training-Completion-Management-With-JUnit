package com.example.demo;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.fail;

import java.time.Instant;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.NoSuchElementException;

import org.junit.Assert;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.dao.EmptyResultDataAccessException;

import com.example.demo.trainee.model.Trainee;
import com.example.demo.trainee.repository.TraineeRepository;
import com.example.demo.training.model.Training;
import com.example.demo.training.repository.TrainingRepository;

@SpringBootTest
public class TrainingTests {

	@Autowired
	private TrainingRepository trainingRepository;

	@Autowired
	private TraineeRepository traineeRepository;

	// create training info
	@Test
	public void testCreateTraining() {
		try {
			Training training = new Training();
			training.setTrainingId(Instant.now().toEpochMilli());
			training.setActName("Sample");
			training.setAvailDate(LocalDate.now().plusDays(53));
			training.setDueDate(LocalDate.now().plusDays(53));

			// Validate the required fields
			if (training.getActName() == null || training.getActName().isEmpty()) {
				throw new IllegalArgumentException(" Error: Activity name is required.");
			}
			if (training.getAvailDate() == null) {
				throw new IllegalArgumentException(" Error: Availability date is required.");
			}
			if (training.getDueDate() == null) {
				throw new IllegalArgumentException(" Error: Due date is required.");
			}

			trainingRepository.save(training);
			
		} catch (IllegalArgumentException e) {
			fail("All fields are required: " + e.getMessage());
		} catch (Exception e) {
			fail("Exception thrown while creating trainee: " + e.getMessage());
		}
	}

	// read all the training 
	@Test
	public void testReadAll() {
		try {
			List<Training> training = trainingRepository.findAll();

			assertNotNull(training, "Training list should not be null");
			assertThat(training.size()).as("Expected training list size to be greater than 10").isGreaterThan(1);

		} catch (EmptyResultDataAccessException e) {
			fail("No trainings found in the database");
		} catch (IllegalArgumentException e) {
			fail("Invalid argument passed to findAll method");
		}
	}

	private void assertNotNull(List<Training> training, String string) {
		// TODO Auto-generated method stub

	}

	// read single training info
	@Test
	public void testTrainingInfo() {
		Long trainingId = 1L;
		try {
			Training training = trainingRepository.findById(trainingId)
					.orElseThrow(() -> new NoSuchElementException("No training found with ID " + trainingId));
			assertThat(training.getActName().equalsIgnoreCase("Onboarding")).isTrue();

		} catch (IllegalArgumentException e) {
			fail(e.getMessage());
		} catch (Exception e) {
			fail("Exception thrown while reading trainee info: " + e.getMessage());
		}
	}

	// update existing training info
	@Test
	public void testInfoUpdate() {
		Long trainingId = 502L;

		try {
			Training training = trainingRepository.findById(trainingId)
					.orElseThrow(() -> new NoSuchElementException("No training found with ID " + trainingId));

			training.setActName("Other Access Related Request");
			training.setAvailDate(LocalDate.now().plusDays(10));
			training.setDueDate(LocalDate.now().plusDays(15));

			// Validate the required fields
			if (training.getActName() == null || training.getActName().isEmpty()) {
				throw new IllegalArgumentException(" Error: Activity name is required.");
			}
			if (training.getAvailDate() == null) {
				throw new IllegalArgumentException(" Error: Availability date is required.");
			}
			if (training.getDueDate() == null) {
				throw new IllegalArgumentException(" Error: Due date is required.");
			}

			trainingRepository.save(training);

			Training updatedTraining = trainingRepository.findById(trainingId)
					.orElseThrow(() -> new NoSuchElementException("No training found with ID " + trainingId));

			Assert.assertNotNull(updatedTraining);

		} catch (IllegalArgumentException e) {
			fail("All fields are required: " + e.getMessage());
		} catch (Exception e) {
			fail("Exception thrown: " + e.getMessage());
		}

	}

	// delete training info
	// cannot delete training that is assigned to trainee (in progress)
	@Test
	public void testTrainingDelete() {
		Long trainingId = 902L;

		try {
			boolean existsBefore = trainingRepository.existsById(trainingId);
			if (!existsBefore) {
				throw new NoSuchElementException("No training found with ID " + trainingId);
			}

			// check whether the training is assigned to any trainee
			Optional<Trainee> assignedTrainee = traineeRepository.findById(trainingId);
			if (assignedTrainee.isPresent()) {
				throw new IllegalStateException("Cannot delete training ID " + trainingId
						+ " that is assigned to trainee ID " + assignedTrainee.get().getTraineeId());
			}

			trainingRepository.deleteById(trainingId);
			assertFalse(trainingRepository.existsById(trainingId));

		} catch (Exception e) {
			fail("Exception thrown: " + e.getMessage());
		}
	}

}
